interrupts.o: interrupts.c
interrupts.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
interrupts.o: interrupts.h
