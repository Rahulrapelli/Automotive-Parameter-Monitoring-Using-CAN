can.o: can.c
can.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
can.o: types.h
can.o: delay.h
can.o: can_defines.h
can.o: types.h
can.o: can.h
can.o: types.h
